matric number: A0098997U
Drawing 1:-
� Primitives and transformations you have used
  -GL_POLYGON
  -glRotatef(), glTranslatef(), glScalef()

� What you are drawing
  -3D sphere with multiple shading(smooth,flat,wireframe,vertices)

� Methods you have modified 
  � changed glclearcolor() in main for background color 
  - added new functions 
 
� Any other things I should know?
  -added normal calculation for proper highlighting
  -for smooth shading the normal is basically the vertices itself 
  - for flat shading I took the midpoint of each small polygon 




Drawing 2:-
� Primitives and transformations you have used
  -GL_POLYGON
  -glRotatef(), glTranslatef(), glScalef()

� What you are drawing
  -3D cone with multiple shading(smooth,flat,wireframe,vertices)

� Methods you have modified 
  � changed glclearcolor() in main for background color 
  - added new functions 
 
� Any other things I should know?
  -added normal calculation for proper highlighting
  -for smooth shading the normal is basically the vertices itself 
  - for flat shading I took the midpoint of each small polygon 


Drawing 3:-
� Primitives and transformations you have used
  -GL_POLYGON
  -glRotatef(), glTranslatef(), glScalef()

� What you are drawing
  -Magical Wish Wand with multiple shading(smooth,flat,wireframe,vertices)

� Methods you have modified 
  � changed glclearcolor() in main for background color 
  - added multiple new functions 
 
� Any other things I should know?
  -the main sphere of the wand composed of small sections of a sphere and rotated
to form that
  -added normal calculation for proper highlighting
  -for smooth shading the normal is basically the vertices itself 
  - for flat shading I took the midpoint of each small polygon 

� What is the coolest thing(s) in your drawing
  - Its a non existent wand(i.e. not a replica from existing anime) created with \
my imagination with the help of opengl :)


Drawing 4:-
� Primitives and transformations you have used
  -GL_POLYGON
  -glRotatef(), glTranslatef(), glScalef()

� What you are drawing
  -Percussion drum set with multiple shading(smooth,flat,wireframe,vertices)

� Methods you have modified 
  � changed glclearcolor() in main for background color 
  - added new functions 
 
� Any other things I should know?
  -added normal calculation for proper highlighting
  -for smooth shading the normal is basically the vertices itself 
  - for flat shading I took the midpoint of each small polygon 

� What is the coolest thing(s) in your drawing
  -instead of only 3D, i used some 2D drawings to make the model look more realistic
  -The arrangement is according how an actual band set should be ,only thing missing 
is the drummer!